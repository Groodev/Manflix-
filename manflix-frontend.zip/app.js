// Manflix frontend (minimal)
const API_BASE = window.API_BASE || "/api"; // <-- if you run the provided API locally, serve frontend from same host or set window.API_BASE before loading script

const grid = document.getElementById('grid');
const tpl = document.getElementById('card-tpl');
const btnHamb = document.getElementById('btn-hamburger');
const sidebar = document.getElementById('sidebar');
const btnClose = document.getElementById('btn-close');
const searchInput = document.getElementById('search');
const btnSearch = document.getElementById('btn-search');

btnHamb.addEventListener('click', ()=> sidebar.classList.add('open'));
btnClose.addEventListener('click', ()=> sidebar.classList.remove('open'));

async function fetchList(query=''){
  // This tries several common endpoints so it works with many manga API structures.
  const tryEndpoints = [
    `${API_BASE}/manga`,
    `${API_BASE}/manhwa`,
    `${API_BASE}/series`,
    `${API_BASE}/comic`,
    `${API_BASE}/list`,
    `${API_BASE}/kurokami`,
    `${API_BASE}/search?q=${encodeURIComponent(query)}`
  ];

  for(const url of tryEndpoints){
    try{
      const res = await fetch(url);
      if(!res.ok) continue;
      const data = await res.json();
      // attempt to normalize common structures
      let items = data;
      if(data.manga) items = data.manga;
      if(data.results) items = data.results;
      if(data.data) items = data.data;
      if(!Array.isArray(items)) continue;
      renderItems(items);
      return;
    }catch(e){
      // ignore and try next
    }
  }
  // fallback: show message
  grid.innerHTML = `<div style="padding:30px;color:#fff">Tidak dapat mengambil list dari API. Pastikan API berjalan dan base path API di file app.js sesuai.</div>`;
}

function renderItems(items){
  grid.innerHTML = '';
  for(const it of items){
    const node = tpl.content.cloneNode(true);
    const img = node.querySelector('.thumb');
    const title = node.querySelector('.title');
    const ch = node.querySelector('.chapter');
    // attempt to read common fields
    img.src = it.thumbnail || it.thumb || it.image || it.cover || it.poster || it.img || '';
    img.onerror = ()=> { img.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="600"><rect width="100%" height="100%" fill="%23111111"/><text x="50%" y="50%" fill="%23fff" font-size="20" text-anchor="middle">No+Image</text></svg>' };
    title.textContent = it.title || it.name || it.nama || it.judul || 'Untitled';
    ch.textContent = it.chapter || it.latest || (it.last_chapter ? `Ch ${it.last_chapter}` : (it.type || '—'));
    const article = node.querySelector('article');
    article.style.cursor = 'pointer';
    article.addEventListener('click', ()=> openReader(it));
    grid.appendChild(node);
  }
}

function openReader(item){
  // Attempt to open a reader page; if API has endpoint for chapters, try to open it.
  const slug = item.slug || item.id || item._id || item.url || '';
  if(slug){
    // open detail in new tab — you can build detail.html to expand later
    const tryUrls = [
      `${API_BASE}/manga/${slug}`,
      `${API_BASE}/manhwa/${slug}`,
      `${API_BASE}/series/${slug}`,
      `${API_BASE}/comic/${slug}`
    ];
    window.open(tryUrls[0], '_blank');
  } else {
    alert('Detail tidak tersedia untuk item ini.');
  }
}

btnSearch.addEventListener('click', ()=> fetchList(searchInput.value));
searchInput.addEventListener('keyup', (e)=> { if(e.key === 'Enter') fetchList(searchInput.value); });

// initial load
fetchList();
