Manflix - Frontend (minimal)

Files included:
- index.html
- styles.css
- app.js

How to connect:
1. Jalankan API yang kamu upload (kurokami-manhwa-api) sesuai instruksi pada paket API (biasanya `npm install` lalu `npm start`).
2. Serve frontend ini dari origin yang sama atau set `window.API_BASE` di console devtools, misal:
   window.API_BASE = 'http://localhost:3000/api';
3. Buka index.html di browser. Frontend akan mencoba beberapa endpoint umum (lihat app.js).
4. Kalau butuh halaman reader/detail, saya bisa tambahkan file detail.html dan logika pembacaan.

Saya juga menemukan file dalam API yang mungkin relevan (coba periksa di folder kurokami-api):

kurokami-manhwa-api-main/README.md
kurokami-manhwa-api-main/api/server.js
kurokami-manhwa-api-main/src/app.js
kurokami-manhwa-api-main/src/controllers/scrapingController.js
kurokami-manhwa-api-main/src/routes/apiRoutes.js